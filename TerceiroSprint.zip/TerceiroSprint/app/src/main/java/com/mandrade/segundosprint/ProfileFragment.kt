package com.mandrade.segundosprint

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    private lateinit var usernameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var addressInput: EditText
    private lateinit var cnpjInput: EditText

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        usernameInput = view.findViewById(R.id.edtName)
        phoneInput = view.findViewById(R.id.edtPhone)
        addressInput = view.findViewById(R.id.edtAddress)
        cnpjInput = view.findViewById(R.id.edtCnpj)

        loadProfileData()

        return view
    }

    private fun loadProfileData() {
        val sharedPreferences =
            requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val userKey = "user_${sharedPreferences.getString("current_email", "")}"

        val username = sharedPreferences.getString("$userKey.username", "")
        val phone = sharedPreferences.getString("$userKey.phone", "")
        val address = sharedPreferences.getString("$userKey.address", "")
        val cnpj = sharedPreferences.getString("$userKey.cnpj", "")

        usernameInput.setText(username)
        phoneInput.setText(phone)
        addressInput.setText(address)
        cnpjInput.setText(cnpj)
    }
}