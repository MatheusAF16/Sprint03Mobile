package com.mandrade.segundosprint

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        val registerButton = findViewById<Button>(R.id.btnCriarConta)
        val usernameInput = findViewById<EditText>(R.id.edtName)
        val passwordInput = findViewById<EditText>(R.id.edtPassword)
        val cnpjInput = findViewById<EditText>(R.id.edtCnpj)
        val emailInput = findViewById<EditText>(R.id.edtAddress)
        val phoneInput = findViewById<EditText>(R.id.edtPhone)

        registerButton.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            val cnpj = cnpjInput.text.toString()
            val email = emailInput.text.toString()
            val phone = phoneInput.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty() && cnpj.isNotEmpty() && email.isNotEmpty() && phone.isNotEmpty()) {
                verificarCnpj(cnpj, username, password, email, phone)
            } else {
                Toast.makeText(this, "Todos os campos são obrigatórios!", Toast.LENGTH_SHORT).show()
            }
        }

        val backToLoginButton = findViewById<Button>(R.id.btnJaTenhoConta)
        backToLoginButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun verificarCnpj(
        cnpj: String,
        username: String,
        password: String,
        email: String,
        phone: String
    ) {
        RetrofitInstance.api.getCnpjInfo(cnpj).enqueue(object : Callback<CnpjResponse> {
            override fun onResponse(call: Call<CnpjResponse>, response: Response<CnpjResponse>) {
                if (response.isSuccessful && response.body() != null && response.body()?.error == null) {
                    salvarUsuario(username, password, cnpj, email, phone)
                } else {
                    Toast.makeText(
                        this@CadastroActivity,
                        "CNPJ não encontrado!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<CnpjResponse>, t: Throwable) {
                Toast.makeText(
                    this@CadastroActivity,
                    "Erro ao verificar CNPJ. Tente novamente.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun salvarUsuario(
        username: String,
        password: String,
        cnpj: String,
        email: String,
        phone: String
    ) {
        val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        val userKey = "user_$email" // Utilizando o email como chave
        editor.putString("$userKey.username", username)
        editor.putString("$userKey.password", password)
        editor.putString("$userKey.cnpj", cnpj)
        editor.putString("$userKey.email", email)
        editor.putString("$userKey.phone", phone)
        editor.apply()

        Toast.makeText(this, "Cadastro bem-sucedido! Faça login.", Toast.LENGTH_SHORT).show()

        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }
}
