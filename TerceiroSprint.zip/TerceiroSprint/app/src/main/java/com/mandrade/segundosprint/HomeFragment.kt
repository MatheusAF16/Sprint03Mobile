package com.mandrade.segundosprint

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction


class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnEntrar = view.findViewById<Button>(R.id.btnEntrar)
        btnEntrar.setOnClickListener {
            // Substitua LoginActivity pelo nome da sua Activity de login
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
        }

        val btnCriarConta = view.findViewById<Button>(R.id.btnCriarConta)
        btnCriarConta.setOnClickListener {
            // Substitua CadastroActivity pelo nome da sua Activity de cadastro
            val intent = Intent(requireContext(), CadastroActivity::class.java)
            startActivity(intent)
        }

        val btnSobre = view.findViewById<Button>(R.id.btnSobre)
        btnSobre.setOnClickListener {
            // Substitua SobreFragment pelo nome da classe do seu fragmento de sobre
            val sobreFragment = SobreFragment()
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, sobreFragment)
                .addToBackStack(null)
                .commit()
        }
    }
}


