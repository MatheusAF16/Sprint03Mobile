package com.mandrade.segundosprint

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginButton = findViewById<Button>(R.id.login_button)
        val emailInput = findViewById<EditText>(R.id.email_input)
        val passwordInput = findViewById<EditText>(R.id.password_input)

        loginButton.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Nome de usuário e senha não podem estar vazios!", Toast.LENGTH_SHORT).show()
            } else {
                val sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
                val userKey = "user_$email"
                val storedUsername = sharedPreferences.getString("$userKey.username", null)
                val storedPassword = sharedPreferences.getString("$userKey.password", null)
                val storedPhone = sharedPreferences.getString("$userKey.phone", null)
                val storedEmail = sharedPreferences.getString("$userKey.email", null)


                if (storedEmail != null && storedPassword != null && email == storedEmail && password == storedPassword) {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("username", storedUsername)
                    intent.putExtra("email", email)
                    intent.putExtra("password", password)
                    intent.putExtra("phone", storedPhone)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Email ou senha incorretos!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val registerButton = findViewById<Button>(R.id.login_button)
        registerButton.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }
    }
}