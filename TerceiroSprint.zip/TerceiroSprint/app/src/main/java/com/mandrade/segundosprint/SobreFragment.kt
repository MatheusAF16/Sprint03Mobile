package com.mandrade.segundosprint

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Button

class SobreFragment : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_sobre)

        val btnVoltar: Button = findViewById(R.id.btnVoltar)
        btnVoltar.setOnClickListener {
            finish()
        }
    }
}

