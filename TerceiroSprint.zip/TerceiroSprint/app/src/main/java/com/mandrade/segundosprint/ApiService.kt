package com.mandrade.segundosprint

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("buscarcnpj")
    fun getCnpjInfo(@Query("cnpj") cnpj: String): Call<CnpjResponse>
}
