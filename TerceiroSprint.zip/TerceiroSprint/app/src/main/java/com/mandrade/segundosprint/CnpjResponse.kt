package com.mandrade.segundosprint

import com.google.gson.annotations.SerializedName

data class CnpjResponse(
    @SerializedName("CNPJ")
    val cnpj: String?,
    @SerializedName("RAZAO SOCIAL")
    val razaoSocial: String?,
    @SerializedName("NOME FANTASIA")
    val nomeFantasia: String?,
    @SerializedName("STATUS")
    val status: String?,
    @SerializedName("error")
    val error: String?
    // Adicione outros campos conforme necessário
)
