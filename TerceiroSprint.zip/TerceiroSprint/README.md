# Nomes dos integrantes:
# Gabriel Ortiz Oliva Gil - RM: 98642 – 2TDSPK
# Rafael Noboru Watanabe Nasaha - RM:99948 – 2TDSPK
# João Pedro Kraide Máximo - RM:550974 – 2TDSPK
# Matheus de Andrade Ferreira - RM:99375 – 2TDSPK
# Larissa Pereira Biusse - RM:551062 - 2TDSPK